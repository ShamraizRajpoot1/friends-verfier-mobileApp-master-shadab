export const MainUrl =
  // "https://5410-125-63-124-68.ngrok-free.app/dev";
  "https://ih2tx3721j.execute-api.us-east-1.amazonaws.com/dev";
