/** @format */

export const LOGIN_DETAILS = "LOGIN_DETAILS";
export const LOG_OUT = "LOG_OUT";
export const TOTAL_SEARCH = "TOTAL_SEARCH";
export const SUB_REM = "SUB_REM";
export const PENDING_SEARCH = "PENDING_SEARCH";
