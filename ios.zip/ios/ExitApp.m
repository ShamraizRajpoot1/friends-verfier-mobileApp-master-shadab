//
//  ExitApp.m
//  FriendVerifier
//
//  Created by Shadab Hussain on 16/04/2023.
//
#import "ExitApp.h"
@implementation RCTCalendarModule
RCT_EXPORT_MODULE(CalendarModuleFoo);
@end


