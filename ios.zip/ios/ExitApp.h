//
//  ExitApp.h
//  FriendVerifier
//
//  Created by Shadab Hussain on 16/04/2023.
//

//  RCTCalendarModule.h
#import <React/RCTBridgeModule.h>
@interface RCTCalendarModule : NSObject <RCTBridgeModule>
@end
