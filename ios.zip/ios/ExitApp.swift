//
//  ExitApp.swift
//  FriendVerifier
//
//  Created by Shadab Hussain on 16/04/2023.
//

import Foundation
